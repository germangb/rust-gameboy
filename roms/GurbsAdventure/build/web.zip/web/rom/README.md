Add your ROM here named as game.gb
or edit the romPath in js/other/mobile.js to point to your ROM file.
